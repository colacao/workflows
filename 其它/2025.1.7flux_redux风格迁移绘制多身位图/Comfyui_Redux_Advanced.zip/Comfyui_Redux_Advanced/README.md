

![image](https://github.com/user-attachments/assets/02b45893-cc2f-4dd1-aae9-a83d28b1a395)

Redux can be used with openpose  
The reference picture on the left below comes from Xiaohongshu blogger - Xiaoxiaona
下面的左边参考图来自小红书博主: 一只小小娜 (友情赞助)
![860f72b57150c9b62ee1b9516bacae0](https://github.com/user-attachments/assets/6316407d-d392-453e-b295-680242ecafad)

关于我 | About me

Bilibili：[我的B站主页](https://space.bilibili.com/498399023?spm_id_from=333.1007.0.0)
QQ群：3260561522
wechat微信: DLONG189one

欢迎赞助投喂
